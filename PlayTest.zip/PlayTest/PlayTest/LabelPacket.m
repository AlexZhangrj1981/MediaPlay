//
//  LabelPacket.m
//  LittleField
//
//  Created by chenp on 16/10/29.
//  Copyright © 2016年 chenp. All rights reserved.
//

#import "LabelPacket.h"

@implementation LabelPacket


+(UILabel *)initWithFont:(NSInteger )font initialX:(CGFloat)x initialY:(CGFloat)y width:(CGFloat)textWidth text:(NSString *)text textColor:(UIColor *)color
{
    UILabel *label=[[UILabel alloc] init];
    label.font=[UIFont systemFontOfSize:font];
    label.text=text;
    label.textColor=color;
    label.numberOfLines=0;
    CGRect txRect = [label.text boundingRectWithSize:CGSizeMake(textWidth, 400*10) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:label.font} context:nil];
    label.frame=CGRectMake(x, y, textWidth, txRect.size.height);
    
    return label;
}



@end
