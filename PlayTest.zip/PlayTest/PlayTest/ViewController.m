//
//  ViewController.m
//  PlayTest
//
//  Created by chenp on 2017/9/6.
//  Copyright © 2017年 chenp. All rights reserved.
//

#import "ViewController.h"
#import "MoviePlayerViewController.h"
#import "PlayModel.h"

@interface ViewController ()<PlayDelegate>

@end

@implementation ViewController

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[PlayModel shareInstance] pause];
    [PlayModel shareInstance].playDelegate = nil;//不用时要设置为nil，否则在同一个项目中视频和音频都需要播放时会偶尔崩溃
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //音频
    [PlayModel shareInstance].playDelegate = self;
    [[PlayModel shareInstance] initAudioPlayerWithUrl:[NSURL URLWithString:@""]];
    
    //视频
    MoviePlayerViewController *movieplayer = [MoviePlayerViewController new];
    movieplayer.playUrl = @"";//远程视频
//    movieplayer.localUrl = [NSURL URLWithString:@""];//本地视频
    [self.navigationController pushViewController:movieplayer animated:YES];
}


-(void)playBegin{
    
}
-(void)playEnd{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}


@end
