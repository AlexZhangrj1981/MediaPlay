//
//  LabelPacket.h
//  LittleField
//
//  Created by chenp on 16/10/29.
//  Copyright © 2016年 chenp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface LabelPacket : NSObject

+(UILabel *)initWithFont:(NSInteger )font initialX:(CGFloat)x initialY:(CGFloat)y width:(CGFloat)textWidth text:(NSString *)text textColor:(UIColor *)color;

@end
