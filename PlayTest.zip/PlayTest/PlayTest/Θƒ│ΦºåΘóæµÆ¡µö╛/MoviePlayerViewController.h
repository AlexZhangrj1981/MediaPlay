//
//  MoviePlayerViewController.h
//  VideoDemo
//
//  Created by chenp on 17/3/31.
//  Copyright © 2017年 chenp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MoviePlayerViewController : UIViewController

@property (nonatomic,strong)NSString *playUrl;

@property (nonatomic,strong)NSURL *localUrl;

@end
