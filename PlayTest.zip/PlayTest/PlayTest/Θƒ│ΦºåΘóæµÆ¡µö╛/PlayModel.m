//
//  MusicPlayModel.m
//  VideoDemo
//
//  Created by chenp on 17/3/30.
//  Copyright © 2017年 chenp. All rights reserved.
//

#import "PlayModel.h"


@implementation PlayModel
{
    AVPlayer *audioPlayer;
    AVPlayerItem * playerItem;
    AVPlayerLayer * playerLayer;
    NSInteger currentTime;
}

+(PlayModel *)shareInstance{
    static PlayModel *player = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        player = [[PlayModel alloc] init];
    });
    return player;
}
//音频
-(void)initAudioPlayerWithUrl:(NSURL *)url{
    playerItem = [AVPlayerItem playerItemWithURL:url];
    audioPlayer =[AVPlayer playerWithPlayerItem:playerItem];
    [self start];
    currentTime = 0;
    
//    //支持后台播放 还要在background modes 勾选Audio,AirPlay
//    AVAudioSession *session = [AVAudioSession sharedInstance];
//    [session setActive:YES error:nil];
//    [session setCategory:AVAudioSessionCategoryPlayback error:nil];
}

//视频
-(void)initMoviePlayerWithUrl:(NSURL *)url addToView:(UIView *)view{
    playerItem = [AVPlayerItem playerItemWithURL:url];
    audioPlayer =[[AVPlayer alloc] initWithPlayerItem:playerItem];
    
    playerLayer = [AVPlayerLayer playerLayerWithPlayer:audioPlayer];
    playerLayer.frame = CGRectMake(0, 0, view.frame.size.width, view.frame.size.height);
    [view.layer addSublayer:playerLayer];
    playerLayer.videoGravity =AVLayerVideoGravityResizeAspect;
    
    currentTime = 0;
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t) NSEC_PER_MSEC*1000), dispatch_get_main_queue(), ^{
        [self start];
        _cacheTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(cachesAction) userInfo:nil repeats:YES];
    });
}

-(void)cachesAction{
    NSArray *loadedTimeRanges = [playerItem loadedTimeRanges];
    CMTimeRange timeRange = [loadedTimeRanges.firstObject CMTimeRangeValue];// 获取缓冲区域
    float startSeconds = CMTimeGetSeconds(timeRange.start);
    float durationSeconds = CMTimeGetSeconds(timeRange.duration);
    NSTimeInterval timeInterval = startSeconds + durationSeconds;// 计算缓冲总进度
    CMTime duration = playerItem.duration;
    CGFloat totalDuration = CMTimeGetSeconds(duration);
    if(_playDelegate != nil){
        [_playDelegate cachesProgress:timeInterval / totalDuration];
    }
}



//从特定时间开始播放
-(void)playWithTime:(CGFloat)time{
    [self pause];
    CMTime pointTime = CMTimeMake(time * [self duration], 1);
    currentTime = time * [self duration];//获取播放前的当前时间
    [playerItem seekToTime:pointTime toleranceBefore:kCMTimeZero toleranceAfter:kCMTimeZero];
    [self start];
}


-(void)pause{
    _isplaying = NO;
    [audioPlayer pause];
    if(_timer != nil){
        [_timer invalidate];
        _timer = nil;
    }
}

-(void)start{
    [audioPlayer play];
    if(_timer != nil){
        [_timer invalidate];
        _timer = nil;
    }
    //获取播放进度
    _timer = [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(progressAction) userInfo:nil repeats:YES];
    
    //播放开始的通知
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"PlayStart" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playStart:) name:@"PlayStart" object:nil];
    
    //播放结束的通知
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"PlayEnd" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playEnd:) name:@"PlayEnd" object:nil];
}



-(void)playStart:(NSNotification *)notification{
    if(_playDelegate != nil && [_playDelegate conformsToProtocol:@protocol(PlayDelegate)]){
        _isplaying = YES;
        [_playDelegate playBegin];
        //移除播放开始的通知，使播放开始只触发一次
        [[NSNotificationCenter defaultCenter] removeObserver:self name:@"PlayStart" object:nil];
    }
}

-(void)playEnd:(NSNotification *)notification{
    if(_playDelegate != nil){
        [self pause];
        [_playDelegate playEnd];
        [[NSNotificationCenter defaultCenter] removeObserver:self name:@"PlayEnd" object:nil];
    }
}

-(void)progressAction{
    if(currentTime < [self currentTime]){//当前时间比播放前的时间大，播放开始
        [[NSNotificationCenter defaultCenter] postNotificationName:@"PlayStart" object:nil userInfo:nil];
    }
    if([self currentTime] >= [self duration]){//播放结束
        [[NSNotificationCenter defaultCenter] postNotificationName:@"PlayEnd" object:nil userInfo:nil];
    }
    
    if(_isplaying){
        if(_playDelegate != nil){
            [_playDelegate playingProgress:[self currentTime]/[self duration]];
        }
    }
}


-(CGFloat)currentTime{
    return CMTimeGetSeconds(playerItem.currentTime);
}

-(CGFloat)duration{
    return CMTimeGetSeconds(playerItem.duration);
}

@end
