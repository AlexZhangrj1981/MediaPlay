//
//  MoviePlayerViewController.m
//  VideoDemo
//
//  Created by chenp on 17/3/31.
//  Copyright © 2017年 chenp. All rights reserved.
//

#import "MoviePlayerViewController.h"
#import "PlayModel.h"
#import "LabelPacket.h"

static const NSInteger kRectCount = 5;
static const CGFloat kSpaceBetweenRect = 3.0;

#define screen_width [UIScreen mainScreen].bounds.size.width
#define screen_height [UIScreen mainScreen].bounds.size.height

@interface MoviePlayerViewController ()<PlayDelegate>

@property (nonatomic,assign)NSInteger seconds;
@property (nonatomic,strong)UISlider *slider;
@property (nonatomic,strong)UISlider *cachesSlider;
@property (nonatomic,strong)UIView *loadingView;
@property (nonatomic,strong)UIButton *playButton;
@property (nonatomic,strong)UILabel *currentLabel;
@property (nonatomic,strong)UILabel *totoalLabel;
@property (nonatomic,strong)UIView *bottomView;
@property (nonatomic,strong)UIButton *playOrPauseBut;
@property (nonatomic,strong)UIButton *completeButton;
@property (nonatomic,strong)NSTimer *timer;

@end

@implementation MoviePlayerViewController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.hidden = YES;
    _seconds = 10;
    _timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(timeAction) userInfo:nil repeats:YES];
}

-(void)timeAction{
    if([PlayModel shareInstance].isplaying){
        _seconds++;
        if(_seconds > 3){
            _bottomView.hidden = YES;
            _completeButton.hidden = YES;
        }else{
            _bottomView.hidden = NO;
            _completeButton.hidden = NO;
        }
    }
    
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    if(_bottomView.hidden){
        _seconds = 0;
        _bottomView.hidden = NO;
        _completeButton.hidden = NO;
    }else{
        _seconds = 10;
        _bottomView.hidden = YES;
        _completeButton.hidden = YES;
    }
}


-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[PlayModel shareInstance] pause];
    if(_timer != nil){
        [_timer invalidate];
        _timer = nil;
    }
    if([PlayModel shareInstance].cacheTimer != nil){
        [[PlayModel shareInstance].cacheTimer invalidate];
        [PlayModel shareInstance].cacheTimer = nil;
        [PlayModel shareInstance].playDelegate = nil;//防止与音频的冲突崩溃
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor=[UIColor whiteColor];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:button];
//    _playUrl = [@"http://secvisiter.jiazi-it.com/Uploads/tmp/background location.mov" stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    UIView *view = [[UIView alloc] initWithFrame:self.view.frame];
    view.backgroundColor = [UIColor blackColor];
    [self.view addSubview:view];
    
    [PlayModel shareInstance].playDelegate = self;
    if(_localUrl != nil){
        [[PlayModel shareInstance] initMoviePlayerWithUrl:_localUrl addToView:self.view];
    }else{
        [[PlayModel shareInstance] initMoviePlayerWithUrl:[NSURL URLWithString:_playUrl] addToView:self.view];
    }
    
    [self layout];
}

-(void)layout{
    _completeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _completeButton.frame = CGRectMake(10, 20, 40, 40);
    _completeButton.layer.cornerRadius = 20;
    _completeButton.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
    [_completeButton setImage:[UIImage imageNamed:@"back"] forState:0];
    [_completeButton addTarget:self action:@selector(buttonAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_completeButton];
    
    
    [self initLoadingView];
    
    [self initBottomView];
    
    _playButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _playButton.frame = CGRectMake(screen_width/2-50, screen_height/2-50, 100, 100);
    [_playButton setImage:[UIImage imageNamed:@"video"] forState:0];
    [_playButton addTarget:self action:@selector(plaAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_playButton];
    _playButton.hidden = YES;
}

-(void)buttonAction{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)plaAction{
    _slider.value = 0;
    [[PlayModel shareInstance] playWithTime:_slider.value];
    _loadingView.hidden = NO;
    _playButton.hidden = YES;
    _playOrPauseBut.tag = 1;
    [_playOrPauseBut setImage:[UIImage imageNamed:@"pause"] forState:0];
}


#pragma mark-加载动画
-(void)initLoadingView{
    _loadingView = [[UIView alloc] initWithFrame: CGRectMake(screen_width/2-50, screen_height/2-50, 100, 100)];
    _loadingView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_loadingView];
    
    CGFloat rectWidth = (_loadingView.frame.size.width - kSpaceBetweenRect *(kRectCount-1)) / kRectCount;
    for (NSInteger i = 0; i < kRectCount; ++i) {
        CALayer *layer = [CALayer layer];
        layer.transform =  CATransform3DMakeScale(1.0, 0.4, 0.0);
        layer.backgroundColor = [UIColor lightGrayColor].CGColor;
        layer.frame = CGRectMake(i * (rectWidth + kSpaceBetweenRect), 0, rectWidth, _loadingView.frame.size.height);
        [_loadingView.layer addSublayer:layer];
    }
    [self startAnimating];
}

- (void)startAnimating {
    for (NSInteger i = 0; i < kRectCount; ++i) {
        CALayer *layer = _loadingView.layer.sublayers[i];
        CAKeyframeAnimation *animation =  [CAKeyframeAnimation animationWithKeyPath:@"transform"];
        animation.removedOnCompletion = NO;
        animation.repeatCount = MAXFLOAT;
        animation.duration = 1.2;
        
        animation.beginTime = CACurrentMediaTime() + i * 0.1;
        animation.keyTimes = @[@0.0,@0.2, @0.4,@1.0];
        animation.timingFunctions = @[
                                      [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut],
                                      [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut],
                                      [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut],
                                      [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]
                                      ];
        animation.values = @[
                             [NSValue valueWithCATransform3D:CATransform3DMakeScale(1.0, 0.4, 0.0)],
                             [NSValue valueWithCATransform3D:CATransform3DMakeScale(1.0, 1.0, 0.0)],
                             [NSValue valueWithCATransform3D:CATransform3DMakeScale(1.0, 0.4, 0.0)],
                             [NSValue valueWithCATransform3D:CATransform3DMakeScale(1.0, 0.4, 0.0)]
                            ];
        [layer addAnimation:animation forKey:[NSString stringWithFormat:@"wave_animation_%lu",i]];
    }
}

#pragma mark-底部控件
-(void)initBottomView{
    _bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, screen_height-80, screen_width, 80)];
    _bottomView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
    [self.view addSubview: _bottomView];
    _bottomView.hidden = YES;
    
    _playOrPauseBut = [UIButton buttonWithType:UIButtonTypeCustom];
    _playOrPauseBut.frame = CGRectMake(0, 15, 50, 50);
    [_playOrPauseBut setImage:[UIImage imageNamed:@"pause"] forState:0];
    _playOrPauseBut.tag = 1;
    [_playOrPauseBut setImageEdgeInsets:UIEdgeInsetsMake(8, 8, 8, 8)];
    [_playOrPauseBut addTarget:self action:@selector(playOrPause:) forControlEvents:UIControlEventTouchUpInside];
    [_bottomView addSubview:_playOrPauseBut];
    
    _currentLabel = [LabelPacket initWithFont:14 initialX:50 initialY:40-9 width:80 text:@"00:00:00" textColor:[UIColor whiteColor]];
    _currentLabel.textAlignment = NSTextAlignmentCenter;
    [_bottomView addSubview:_currentLabel];
    
    
    _totoalLabel = [LabelPacket initWithFont:14 initialX:screen_width-80 initialY:40-9 width:80 text:@"00:00:00" textColor:[UIColor whiteColor]];
    _totoalLabel.textAlignment = NSTextAlignmentCenter;
    [_bottomView addSubview:_totoalLabel];
    
    
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(140, 40-1, screen_width-221.5, 2)];
    view.backgroundColor = [UIColor whiteColor];
    [_bottomView addSubview:view];
    
    _cachesSlider = [[UISlider alloc] initWithFrame:CGRectMake(130, 40-15, screen_width-205, 30)];
    [_bottomView addSubview:_cachesSlider];
    _cachesSlider.maximumTrackTintColor = [UIColor clearColor];
    _cachesSlider.minimumTrackTintColor = [UIColor colorWithRed:200/255.0 green:200/255.0 blue:200/255.0 alpha:1.0];
    [_cachesSlider setThumbImage:[UIImage imageNamed:@"cacheThumb"] forState:UIControlStateHighlighted];
    [_cachesSlider setThumbImage:[UIImage imageNamed:@"cacheThumb"] forState:UIControlStateNormal];
    
    
    _slider = [[UISlider alloc] initWithFrame:CGRectMake(130, 40-15, screen_width-210, 30)];
    [_slider addTarget:self action:@selector(sliderAction) forControlEvents:UIControlEventValueChanged];
    [_slider addTarget:self action:@selector(sliderDown) forControlEvents:UIControlEventTouchDown];
    _slider.continuous = NO;//在手指离开时才触发一次ValueChanged
    _slider.maximumTrackTintColor = [UIColor clearColor];
    [_bottomView addSubview:_slider];
    
    
    UIImage *thumbImage = [UIImage imageNamed:@"sliderThumb"];
    [_slider setThumbImage:thumbImage forState:UIControlStateHighlighted];
    [_slider setThumbImage:thumbImage forState:UIControlStateNormal];
}

-(void)playOrPause:(UIButton *)sender{
    _playOrPauseBut.tag = !_playOrPauseBut.tag;
    if(_playOrPauseBut.tag){
        if(!_playButton.hidden){
            [self plaAction];
        }else{
            [[PlayModel shareInstance] playWithTime:_slider.value];
            _loadingView.hidden = NO;
            [_playOrPauseBut setImage:[UIImage imageNamed:@"pause"] forState:0];
        }
    }else{
        [[PlayModel shareInstance] pause];
        [_playOrPauseBut setImage:[UIImage imageNamed:@"play"] forState:0];
    }
}

#pragma mark-slider event
-(void)sliderDown{
    _playButton.hidden = YES;
    [[PlayModel shareInstance] pause];
}
-(void)sliderAction{
    _playOrPauseBut.tag = 1;
    [_playOrPauseBut setImage:[UIImage imageNamed:@"pause"] forState:0];
    [[PlayModel shareInstance] playWithTime:_slider.value];
    _loadingView.hidden = NO;
    int current = [[PlayModel shareInstance] duration]*_slider.value;
    _currentLabel.text = [NSString stringWithFormat:@"%02d:%02d:%02d",current/3600,(current%3600)/60,current%60];
}

#pragma mark-PlayDelegate

-(void)playBegin{
    _loadingView.hidden = YES;
    int duration = [[PlayModel shareInstance] duration];
    _totoalLabel.text = [NSString stringWithFormat:@"%02d:%02d:%02d",duration/3600,(duration%3600)/60,duration%60];
}

-(void)playEnd{
    _playButton.hidden = NO;
    _playOrPauseBut.tag = 0;
    [_playOrPauseBut setImage:[UIImage imageNamed:@"play"] forState:0];
}

-(void)playingProgress:(CGFloat)progress{
    _slider.value = progress;
    int current = [[PlayModel shareInstance] duration]*progress;
    _currentLabel.text = [NSString stringWithFormat:@"%02d:%02d:%02d",current/3600,(current%3600)/60,current%60];
}

-(void)cachesProgress:(CGFloat)progress{
    _cachesSlider.value = progress;
}

@end
