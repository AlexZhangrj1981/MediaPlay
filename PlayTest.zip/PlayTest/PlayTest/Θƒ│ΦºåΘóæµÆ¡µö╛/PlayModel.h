//
//  MusicPlayModel.h
//  VideoDemo
//
//  Created by chenp on 17/3/30.
//  Copyright © 2017年 chenp. All rights reserved.
//


/*
 
 当不使用时，记得把delegate设置为nil
 
 */


#import <Foundation/Foundation.h>
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>


@protocol PlayDelegate <NSObject>

-(void)playBegin;
-(void)playEnd;

@optional
-(void)playingProgress:(CGFloat )progress;
-(void)cachesProgress:(CGFloat)progress;

@end


@interface PlayModel : NSObject

+(PlayModel *)shareInstance;

-(void)initAudioPlayerWithUrl:(NSURL *)url;
-(void)initMoviePlayerWithUrl:(NSURL *)url addToView:(UIView *)view;
-(void)playWithTime:(CGFloat)time;

-(void)pause;
-(void)start;

-(CGFloat)currentTime;
-(CGFloat)duration;


@property (nonatomic,strong)NSTimer *timer;
@property (nonatomic,strong)NSTimer *cacheTimer;
@property (nonatomic,assign)BOOL isplaying;

@property (nonatomic,assign)id <PlayDelegate>playDelegate;


@end
